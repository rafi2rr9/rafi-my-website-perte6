const express = require('express');
const path = require('path');
// const bodyParser = require('body-parser'); // Tidak perlu jika menggunakan express.urlencoded

const app = express();
const hostname = '127.0.0.1';
const port = 3000;

// =========================================================
// MIDDLEWARE
// =========================================================

// 1. Mengaktifkan penyajian file statis dari folder 'public'
app.use(express.static(path.join(__dirname, 'public')));

// 2. Middleware untuk menangani data POST dari formulir HTML
// Menggunakan middleware bawaan Express
app.use(express.urlencoded({ extended: true }));
// app.use(bodyParser.urlencoded({ extended: true })); // Alternatif body-parser

// =========================================================
// ROUTING GET (Menyajikan Halaman)
// =========================================================

// Route Halaman Home (index.html)
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Route Halaman About
app.get('/about', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'about.html'));
});

// Route Halaman Contact
app.get('/contact', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'contact.html'));
});

// Route Halaman Services
app.get('/services', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'services.html'));
});

// ROUTING DENGAN PARAMETER (seperti yang sudah Anda buat)
app.get('/user/:nama', (req, res) => {
    const namaUser = req.params.nama;
    res.send(`<h1>Selamat Datang, ${namaUser}</h1>`);
});


// =========================================================
// ROUTING POST (Menangani Data Formulir)
// =========================================================

// Route untuk menerima data dari formulir Contact
app.post('/submit-contact', (req, res) => {
    // Data formulir dikirim melalui req.body
    const { nama, email, subjek, pesan } = req.body;
    
    console.log('--- Data Formulir Diterima ---');
    console.log(`Nama: ${nama}`);
    console.log(`Email: ${email}`);
    console.log(`Subjek: ${subjek}`);
    console.log(`Pesan: ${pesan}`);
    console.log('-------------------------------');

    // Kirim respons ke pengguna
    res.send(`
        <h1>Pesan Terkirim!</h1>
        <p>Terima kasih, ${nama}. Pesan Anda telah kami terima.</p>
        <p><a href="/">Kembali ke Home</a></p>
    `);
});


// =========================================================
// MENJALANKAN SERVER
// =========================================================
app.listen(port, hostname, () => {
    console.log(`Server running at http://${hostname}:${port}/`);
});